# Welcome to netflix_as_a_service !


Netflix EU auto provisioning



## License

**netflix_as_a_service** is licensed under the *Apache Software License 2.0* license.

