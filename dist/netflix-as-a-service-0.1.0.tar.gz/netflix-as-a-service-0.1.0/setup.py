# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['netflix_connect_ext']

package_data = \
{'': ['*']}

install_requires = \
['connect-extension-runner>=24.0.0,<25.0.0']

entry_points = \
{'connect.eaas.ext': ['extension = '
                      'netflix_connect_ext.extension:Netflix_as_a_serviceExtension']}

setup_kwargs = {
    'name': 'netflix-as-a-service',
    'version': '0.1.0',
    'description': 'Netflix EU auto provisioning',
    'long_description': '# Welcome to netflix_as_a_service !\n\n\nNetflix EU auto provisioning\n\n\n\n## License\n\n**netflix_as_a_service** is licensed under the *Apache Software License 2.0* license.\n\n',
    'author': 'Gio Corp',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
